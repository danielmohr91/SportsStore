﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MvcDemo.Core.Interfaces;
using AutoMapper.Mappers;

namespace MvcDemo.Core.Mapping
{
    public class MyAutoMapper : IMapper
    {
        public void Reset()
        {          
            throw new NotImplementedException();
        }

        public void Configure()
        {
            throw new NotImplementedException();
        }
    }
}
