﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MvcDemo.Core.Interfaces;

namespace MvcDemo.Core.Mapping
{
    public class AutoMapperRegister : IMapperRegister
    {
        public void Configure()
        {
            throw new NotImplementedException();
        }

        public void Initialize()
        {
            throw new NotImplementedException();
        }
    }
}
