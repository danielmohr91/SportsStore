﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MvcDemo.Core.Interfaces;

namespace MvcDemo.Core.Mapping
{
    public class MapperProvider
    {

    }
}
