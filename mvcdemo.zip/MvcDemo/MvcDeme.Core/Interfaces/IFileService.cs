﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MvcDeme.Core.Models;

namespace MvcDemo.Core.Interfaces
{
    public interface IFileService : IService<FileViewModel>
    {
    }
}
